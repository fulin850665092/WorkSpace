create view user_info_view as
select `user_info`.`id`, `user_info`.`user_name`, `user_info`.`gender`, `user_info`.`user_level`, `user_info`.`area`, `user_info`.`dt` from `default`.`user_info` where `user_info`.`dt`='2019-01-01';

