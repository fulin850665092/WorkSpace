create definer = root@`%` view v_unpaid_orders as
select `gmall`.`order_info`.`id`                    AS `id`,
       `gmall`.`order_info`.`consignee`             AS `consignee`,
       `gmall`.`order_info`.`consignee_tel`         AS `consignee_tel`,
       `gmall`.`order_info`.`final_total_amount`    AS `final_total_amount`,
       `gmall`.`order_info`.`order_status`          AS `order_status`,
       `gmall`.`order_info`.`user_id`               AS `user_id`,
       `gmall`.`order_info`.`delivery_address`      AS `delivery_address`,
       `gmall`.`order_info`.`order_comment`         AS `order_comment`,
       `gmall`.`order_info`.`out_trade_no`          AS `out_trade_no`,
       `gmall`.`order_info`.`trade_body`            AS `trade_body`,
       `gmall`.`order_info`.`create_time`           AS `create_time`,
       `gmall`.`order_info`.`operate_time`          AS `operate_time`,
       `gmall`.`order_info`.`expire_time`           AS `expire_time`,
       `gmall`.`order_info`.`tracking_no`           AS `tracking_no`,
       `gmall`.`order_info`.`parent_order_id`       AS `parent_order_id`,
       `gmall`.`order_info`.`img_url`               AS `img_url`,
       `gmall`.`order_info`.`province_id`           AS `province_id`,
       `gmall`.`order_info`.`benefit_reduce_amount` AS `benefit_reduce_amount`,
       `gmall`.`order_info`.`original_total_amount` AS `original_total_amount`,
       `gmall`.`order_info`.`feight_fee`            AS `feight_fee`
from `gmall`.`order_info`
where (`gmall`.`order_info`.`order_status` = '1001');

-- comment on column v_unpaid_orders.id not supported: 编号

-- comment on column v_unpaid_orders.consignee not supported: 收货人

-- comment on column v_unpaid_orders.consignee_tel not supported: 收件人电话

-- comment on column v_unpaid_orders.final_total_amount not supported: 总金额

-- comment on column v_unpaid_orders.order_status not supported: 订单状态

-- comment on column v_unpaid_orders.user_id not supported: 用户id

-- comment on column v_unpaid_orders.delivery_address not supported: 送货地址

-- comment on column v_unpaid_orders.order_comment not supported: 订单备注

-- comment on column v_unpaid_orders.out_trade_no not supported: 订单交易编号（第三方支付用)

-- comment on column v_unpaid_orders.trade_body not supported: 订单描述(第三方支付用)

-- comment on column v_unpaid_orders.create_time not supported: 创建时间

-- comment on column v_unpaid_orders.operate_time not supported: 操作时间

-- comment on column v_unpaid_orders.expire_time not supported: 失效时间

-- comment on column v_unpaid_orders.tracking_no not supported: 物流单编号

-- comment on column v_unpaid_orders.parent_order_id not supported: 父订单编号

-- comment on column v_unpaid_orders.img_url not supported: 图片路径

-- comment on column v_unpaid_orders.province_id not supported: 地区

-- comment on column v_unpaid_orders.benefit_reduce_amount not supported: 优惠金额

-- comment on column v_unpaid_orders.original_total_amount not supported: 原价金额

-- comment on column v_unpaid_orders.feight_fee not supported: 运费

