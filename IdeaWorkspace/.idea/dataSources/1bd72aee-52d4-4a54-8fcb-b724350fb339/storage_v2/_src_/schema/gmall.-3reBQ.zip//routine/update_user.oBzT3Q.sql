create
    definer = root@`%` procedure update_user()
BEGIN 
UPDATE user_info u SET   u.`user_level`=u.`user_level`+rand_num(0,1) ,gender= IF( rand_num(0,1) >0 , if(rand_num(0,1) =0,'F','M'), gender);
END;

