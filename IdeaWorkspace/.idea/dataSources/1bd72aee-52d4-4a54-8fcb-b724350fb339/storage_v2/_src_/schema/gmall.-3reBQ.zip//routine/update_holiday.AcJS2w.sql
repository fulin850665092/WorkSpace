create
    definer = root@`%` procedure update_holiday(IN year_id int)
BEGIN    
update `date_info` di  
 LEFT JOIN  `holiday_year` hy ON di.`year`=year_id and  hy.year_id=di.`year` AND  di.`date_id`>=hy.`start_date_id` AND di.`date_id`<=hy.`end_date_id`
set   di.holiday_id=  ifnull( hy.`holiday_id`,0);
 COMMIT;
 END;

