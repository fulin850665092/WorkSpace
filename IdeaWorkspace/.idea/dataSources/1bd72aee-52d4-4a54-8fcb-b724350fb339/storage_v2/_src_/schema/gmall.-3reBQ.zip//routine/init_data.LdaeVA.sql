create
    definer = root@`%` procedure init_data(IN do_date_string varchar(20), IN order_incr_num int, IN user_incr_num int,
                                           IN if_truncate tinyint(1))
BEGIN  
     DECLARE user_count INT DEFAULT 0; 
     DECLARE sku_count INT DEFAULT 0; 
     DECLARE do_date VARCHAR(20) DEFAULT do_date_string;
     IF if_truncate  THEN 
        DELETE FROM    order_info ;
        DELETE FROM    order_detail ;
        DELETE FROM     payment_info ;
        DELETE FROM   order_status_log      ;
     END IF ;     
     IF user_incr_num >0 THEN
          CALL insert_user(do_date,user_incr_num,FALSE );
     END IF;
     SELECT COUNT(*) INTO user_count FROM  user_info;
     CALL update_order(do_date);
     CALL insert_order(do_date,order_incr_num,user_count);
     CALL insert_payment(do_date);
     CALL insert_order_status_log(do_date);
 END;

