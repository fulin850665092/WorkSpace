create definer = root@`%` view v_activity_info as
select `gmall`.`activity_info`.`id`            AS `id`,
       `gmall`.`activity_info`.`activity_name` AS `activity_name`,
       `gmall`.`activity_info`.`activity_type` AS `activity_type`,
       `gmall`.`activity_info`.`activity_desc` AS `activity_desc`,
       `gmall`.`activity_info`.`start_time`    AS `start_time`,
       `gmall`.`activity_info`.`end_time`      AS `end_time`,
       `gmall`.`activity_info`.`create_time`   AS `create_time`
from `gmall`.`activity_info`;

-- comment on column v_activity_info.id not supported: 活动id

-- comment on column v_activity_info.activity_name not supported: 活动名称

-- comment on column v_activity_info.activity_type not supported: 活动类型

-- comment on column v_activity_info.activity_desc not supported: 活动描述

-- comment on column v_activity_info.start_time not supported: 开始时间

-- comment on column v_activity_info.end_time not supported: 结束时间

-- comment on column v_activity_info.create_time not supported: 创建时间

