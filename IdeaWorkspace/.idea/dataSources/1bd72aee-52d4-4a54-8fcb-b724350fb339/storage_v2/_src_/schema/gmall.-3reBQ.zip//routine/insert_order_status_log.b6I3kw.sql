create
    definer = root@`%` procedure insert_order_status_log(IN do_date_str varchar(200))
BEGIN      
 INSERT INTO order_status_log ( order_id ,order_status , operate_time  ) 
  SELECT   id ,1 , o.create_time   
  FROM order_info  o 
  WHERE  DATE_FORMAT(o.create_time,'%Y-%m-%d')= do_date_str; 
  
   INSERT INTO order_status_log ( order_id ,order_status , operate_time  ) 
  SELECT   id ,order_status ,  o.operate_time
  FROM order_info  o 
  WHERE    DATE_FORMAT(o.operate_time,'%Y-%m-%d')= do_date_str  ;   
  
  COMMIT;
 END;

