create
    definer = root@`%` procedure insert_user(IN create_time_string varchar(200), IN max_num int,
                                             IN if_truncate tinyint(1))
BEGIN  
 DECLARE v_create_time DATETIME DEFAULT NULL;
 DECLARE i INT DEFAULT 0;
 DECLARE v_birthday DATE DEFAULT now();
 DECLARE v_gender VARCHAR(1) DEFAULT NULL;
 SET autocommit = 0;    
 IF   if_truncate THEN  
   TRUNCATE user_info;
 END IF; 
 
 REPEAT  
   SET i  = i + 1;  
   SET v_create_time=DATE_ADD(DATE_FORMAT(create_time_string,'%Y-%m-%d') ,INTERVAL rand_num(1,3600*24) SECOND); 
   SET v_birthday=DATE_ADD(DATE_FORMAT('1960-01-01','%Y-%m-%d') ,INTERVAL rand_num(1,365*50) DAY); 
   SET v_gender=IF(rand_num(0,1)=0,'M','F');
 INSERT INTO user_info (login_name,nick_name,passwd,NAME,phone_num,email,head_img,user_level,birthday,gender,create_time  ) 
 VALUES (rand_string(20) ,rand_string(20) , CONCAT('pwd',rand_string(20)), rand_string(30), CONCAT('13',rand_nums(0,9,9,''))    ,CONCAT(rand_string(8),'@',rand_string(3),'.com') ,  CONCAT('http://',rand_string(40)), rand_num(1,5),v_birthday,v_gender,v_create_time    ); 
 UNTIL i = max_num  
 END REPEAT; 
 COMMIT;  
 END;

