create
    definer = root@`%` procedure init_spu()
BEGIN  
TRUNCATE TABLE  spu_info;
INSERT INTO  spu_info ( spu_name,description,category3_id,tm_id)
SELECT  SUBSTR(sku_name,1,LOCATE(' ' , sku_name,9) ),concat('共',ct,'个sku') description ,category3_id,tm_id  FROM 
(
SELECT spu_id ,  MAX(sku_name) sku_name,count(*) ct, MAX( category3_id) category3_id,MAX(tm_id) tm_id FROM sku_info
GROUP BY spu_id
)bb ;
END;

