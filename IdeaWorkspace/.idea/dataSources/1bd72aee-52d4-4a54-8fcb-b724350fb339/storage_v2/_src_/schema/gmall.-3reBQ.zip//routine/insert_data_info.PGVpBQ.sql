create
    definer = root@`%` procedure insert_data_info(IN year_id int)
BEGIN  
DECLARE cur_date DATETIME DEFAULT NULL;
DECLARE start_date DATETIME DEFAULT NULL;
DECLARE end_date DATETIME DEFAULT NULL;
    SET start_date =  STR_TO_DATE( CONCAT(year_id,'0101' ) ,'%Y%m%d');  
    SET cur_date=start_date;
    SET end_date =  STR_TO_DATE( CONCAT(year_id,'1231' ) ,'%Y%m%d'); 
    delete from  date_info   where  `year`=year_id;
    WHILE end_date>=cur_date  DO
        INSERT INTO date_info
        VALUES (  CONVERT( DATE_FORMAT(cur_date,'%Y%m%d') , SIGNED  ),
                  WEEKOFYEAR(cur_date),
                  dayofweek(cur_date),  
                  CONVERT( DATE_FORMAT( cur_date,'%d'), SIGNED  ),
                  CONVERT(DATE_FORMAT( cur_date,'%m'), SIGNED  ),
                  QUARTER(cur_date),
                   CONVERT(DATE_FORMAT( cur_date,'%Y'), SIGNED  ),
                  if(DAYOFWEEK(cur_date)=6 or DAYOFWEEK(cur_date) = 7 , 1,0),
                  0);
         SET cur_date= ADDDATE(cur_date,1);
    END WHILE;
    COMMIT;
    CALL `update_holiday`(  year_id);
 END;

