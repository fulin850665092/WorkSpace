create
    definer = root@`%` function rand_num(from_num int, to_num int) returns int
BEGIN   
 DECLARE i INT DEFAULT 0;  
 SET i = FLOOR(from_num +RAND()*(to_num -from_num+1))   ;
RETURN i;  
 END;

