create
    definer = root@`%` procedure insert_order(IN create_time_string varchar(200), IN max_num int, IN user_num int)
BEGIN  
 DECLARE v_create_time DATETIME DEFAULT NULL;
  DECLARE i INT DEFAULT 0;
  DECLARE v_order_status INT DEFAULT 0;  
  DECLARE v_operate_time DATETIME DEFAULT NULL; 
  DECLARE v_order_id INT DEFAULT NULL; 
  DECLARE v_order_detail_num INT DEFAULT NULL; 
  DECLARE j INT DEFAULT 0;
  Declare v_province int DEFAULT 0;
  DECLARE v_skuid VARCHAR(20) DEFAULT NULL;
  DECLARE v_skuname VARCHAR(20) DEFAULT NULL;
 SET autocommit = 0;    
 REPEAT  
 SET i = i + 1;  
 SET v_create_time=DATE_ADD(DATE_FORMAT(create_time_string,'%Y-%m-%d') ,INTERVAL rand_num(30,3600*23) SECOND);
 set v_province=  rand_num(1,9);
  SET v_order_status=rand_num(1,2);  
  IF v_order_status>1 THEN 
     SET v_operate_time= DATE_ADD(v_create_time ,INTERVAL rand_num(30,3600) SECOND);
   ELSE 
     SET v_operate_time=NULL  ;
   END IF ;
 INSERT INTO order_info (consignee, consignee_tel,total_amount ,order_status ,user_id,payment_way,delivery_address,order_comment,out_trade_no,trade_body,create_time,operate_time,expire_time, tracking_no,parent_order_id ,img_url, province_id) 
 VALUES (rand_string(6) , CONCAT('13',rand_nums(0,9,9,'')),CAST(rand_num(50,1000) AS DECIMAL(10,2)) ,v_order_status ,rand_num(1,user_num), rand_num(1,2),rand_string(20),rand_string(20),rand_nums(0,9,10,''),'',v_create_time, v_operate_time,NULL,NULL,NULL,NULL ,v_province); 
  SELECT  LAST_INSERT_ID() INTO v_order_id ;
     SET v_order_detail_num=rand_num(1,5); 
    WHILE j<v_order_detail_num DO
       SET j=j+1;
       SET v_skuid= rand_num(1,11) ;
       INSERT INTO  order_detail  (order_id , sku_id,sku_name ,img_url ,order_price,sku_num,create_time ) 
       select v_order_id ,id,sku_name,CONCAT('http://',rand_string(40)),price,rand_num(1,5) ,v_create_time  from sku_info where id=v_skuid;
    END WHILE;
    SET j=0;
 UNTIL i = max_num  
 END REPEAT;  
 COMMIT;  
 END;

