create definer = root@`%` view v_activity_order as
select `gmall`.`activity_order`.`id`          AS `id`,
       `gmall`.`activity_order`.`activity_id` AS `activity_id`,
       `gmall`.`activity_order`.`order_id`    AS `order_id`,
       `gmall`.`activity_order`.`create_time` AS `create_time`
from `gmall`.`activity_order`;

-- comment on column v_activity_order.id not supported: 编号

-- comment on column v_activity_order.activity_id not supported: 活动id 

-- comment on column v_activity_order.order_id not supported: 订单编号

-- comment on column v_activity_order.create_time not supported: 发生日期

